#include <cctype>       // Provides toupper
#include <iostream>     // Provides cout and cin
#include <cstdlib>      // Provides EXIT_SUCCESS
#include "List.h"  // With value_type defined as an int

using namespace std;
using namespace list_2;


int main( )
{
	List Test;

	Test.add(10);
	
	
}
